package com.mycompany.a2;

/**
 * Custom iSteerable interface for ant class
 * @author PalvinderSingh
 *
 */
public interface iSteerable {
	//Direction left of the ant
	public void directionLeft();
	//Direction right of the ant
	public void directionRight();
}
